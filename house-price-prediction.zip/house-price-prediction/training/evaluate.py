from __future__ import annotations

import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    r2_score,
    mean_absolute_error,
    mean_squared_error,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATASET_PATH = PROJECT_ROOT / "assets" / "data.csv"
MODEL_DIR = PROJECT_ROOT / "models"
MODEL_PATH = MODEL_DIR / "house_model.joblib"
SCALER_PATH = MODEL_DIR / "scaler.joblib"
METRICS_PATH = MODEL_DIR / "evaluation_metrics.json"
PREDICTIONS_PLOT_PATH = MODEL_DIR / "predictions_vs_actual.png"
RESIDUALS_PLOT_PATH = MODEL_DIR / "residuals.png"


def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop(columns=["date", "street", "city", "statezip", "country"], errors="ignore")
    df = df[df["price"] > 10000].copy()
    df.loc[df["yr_renovated"] == 0, "yr_renovated"] = df.loc[df["yr_renovated"] == 0, "yr_built"]
    df["house_age"] = 2026 - df["yr_built"]
    df["renovated"] = (df["yr_renovated"] != df["yr_built"]).astype(int)
    df = df.drop(columns=["yr_built", "yr_renovated"])
    df["has_basement"] = (df["sqft_basement"] > 0).astype(int)
    return df


df = pd.read_csv(DATASET_PATH)
df = preprocess_data(df)

TARGET_COLUMN = "price"
X = df.drop(columns=[TARGET_COLUMN])
y = df[TARGET_COLUMN]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42,
)

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

X_test_scaled = scaler.transform(X_test)
predictions_log = model.predict(X_test_scaled)
predictions = np.expm1(predictions_log)

r2 = r2_score(y_test, predictions)
mae = mean_absolute_error(y_test, predictions)
mse = mean_squared_error(y_test, predictions)
rmse = np.sqrt(mse)
mape = np.mean(np.abs((y_test - predictions) / y_test)) * 100

metrics = {
    "algorithm": "Gradient Boosting",
    "r2_score": float(r2),
    "mae": float(mae),
    "mse": float(mse),
    "rmse": float(rmse),
    "mape": float(mape),
    "dataset_rows": int(len(df)),
    "dataset_columns": int(len(df.columns)),
}
with open(METRICS_PATH, "w", encoding="utf-8") as f:
    json.dump(metrics, f, indent=4)
print(f"Metrics saved: {METRICS_PATH}")

plt.figure(figsize=(8, 6))
plt.scatter(y_test, predictions, alpha=0.5, color="#3b82f6")
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
plt.xlabel("Actual Price ($)")
plt.ylabel("Predicted Price ($)")
plt.title("Predictions vs Actual")
plt.tight_layout()
plt.savefig(PREDICTIONS_PLOT_PATH)
plt.close()
print(f"Predictions plot saved: {PREDICTIONS_PLOT_PATH}")

residuals = y_test - predictions
plt.figure(figsize=(8, 6))
plt.scatter(predictions, residuals, alpha=0.5, color="#ef4444")
plt.axhline(y=0, color='r', linestyle='--', lw=2)
plt.xlabel("Predicted Price ($)")
plt.ylabel("Residuals ($)")
plt.title("Residual Plot")
plt.tight_layout()
plt.savefig(RESIDUALS_PLOT_PATH)
plt.close()
print(f"Residuals plot saved: {RESIDUALS_PLOT_PATH}")

print()
print("Evaluation Completed")
print(f"R2 Score : {r2:.4f}")
print(f"MAE      : ${mae:,.2f}")
print(f"RMSE     : ${rmse:,.2f}")
print(f"MAPE     : {mape:.2f}%")
