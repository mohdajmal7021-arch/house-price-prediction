from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import r2_score


PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATASET_PATH = PROJECT_ROOT / "assets" / "data.csv"

MODEL_DIR = PROJECT_ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

MODEL_PATH = MODEL_DIR / "house_model.joblib"
SCALER_PATH = MODEL_DIR / "scaler.joblib"
METADATA_PATH = MODEL_DIR / "training_metadata.json"


def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop(columns=["date", "street", "city", "statezip", "country"], errors="ignore")

    df = df[df["price"] > 10000].copy()

    df.loc[df["yr_renovated"] == 0, "yr_renovated"] = df.loc[df["yr_renovated"] == 0, "yr_built"]
    df["house_age"] = 2026 - df["yr_built"]
    df["renovated"] = (df["yr_renovated"] != df["yr_built"]).astype(int)
    df = df.drop(columns=["yr_built", "yr_renovated"])

    df["has_basement"] = (df["sqft_basement"] > 0).astype(int)

    return df


print("Loading dataset...")
df = pd.read_csv(DATASET_PATH)
print(f"Dataset Shape: {df.shape}")

df = preprocess_data(df)

TARGET_COLUMN = "price"
X = df.drop(columns=[TARGET_COLUMN])
y = df[TARGET_COLUMN]

feature_names = list(X.columns)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42,
)
print(f"Training Samples: {len(X_train)}")
print(f"Testing Samples: {len(X_test)}")

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

y_train_log = np.log1p(y_train)
y_test_log = np.log1p(y_test)

print("Training Gradient Boosting Regressor...")
model = GradientBoostingRegressor(n_estimators=300, learning_rate=0.05, max_depth=5, random_state=42)
model.fit(X_train_scaled, y_train_log)

predictions_log = model.predict(X_test_scaled)
predictions = np.expm1(predictions_log)
r2 = r2_score(y_test, predictions)
print(f"R2 Score: {r2:.4f}")

joblib.dump(model, MODEL_PATH)
joblib.dump(scaler, SCALER_PATH)
print("Model Saved")
print("Scaler Saved")

metadata = {
    "algorithm": "Gradient Boosting",
    "r2_score": float(r2),
    "dataset_rows": int(len(df)),
    "dataset_columns": int(len(df.columns)),
    "features": feature_names,
}
with open(METADATA_PATH, "w", encoding="utf-8") as f:
    json.dump(metadata, f, indent=4)
print("Metadata Saved")
print("Training Completed Successfully")
