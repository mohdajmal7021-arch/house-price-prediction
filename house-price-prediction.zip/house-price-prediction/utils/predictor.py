from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import joblib
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]

MODEL_PATH = PROJECT_ROOT / "models" / "house_model.joblib"
SCALER_PATH = PROJECT_ROOT / "models" / "scaler.joblib"
METADATA_PATH = PROJECT_ROOT / "models" / "training_metadata.json"


@lru_cache(maxsize=1)
def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"Model not found at {MODEL_PATH}. Run training/train.py first."
        )
    return joblib.load(MODEL_PATH)


@lru_cache(maxsize=1)
def load_scaler():
    if not SCALER_PATH.exists():
        raise FileNotFoundError(
            f"Scaler not found at {SCALER_PATH}. Run training/train.py first."
        )
    return joblib.load(SCALER_PATH)


def get_training_metadata():
    if not METADATA_PATH.exists():
        return {}
    with open(METADATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def predict_price(
    bedrooms: float,
    bathrooms: float,
    sqft_living: float,
    sqft_lot: float,
    floors: float,
    waterfront: str,
    view: float,
    condition: float,
    sqft_above: float,
    sqft_basement: float,
    yr_built: float,
    yr_renovated: float,
):
    model = load_model()
    scaler = load_scaler()

    house_age = 2026 - yr_built
    renovated = 1 if yr_renovated != 0 and yr_renovated != yr_built else 0
    has_basement = 1 if sqft_basement > 0 else 0

    feature_dict = {
        "bedrooms": bedrooms,
        "bathrooms": bathrooms,
        "sqft_living": sqft_living,
        "sqft_lot": sqft_lot,
        "floors": floors,
        "waterfront": int(waterfront) if waterfront else 0,
        "view": view,
        "condition": condition,
        "sqft_above": sqft_above,
        "sqft_basement": sqft_basement,
        "house_age": house_age,
        "renovated": renovated,
        "has_basement": has_basement,
    }

    metadata = get_training_metadata()
    expected_features = metadata.get("features", list(feature_dict.keys()))
    data = pd.DataFrame([feature_dict])
    data = data[expected_features]

    scaled_data = scaler.transform(data)
    predicted_log = model.predict(scaled_data)[0]
    predicted_price = float(np.expm1(predicted_log))

    return {
        "predicted_price": round(predicted_price, 2),
    }


def get_dashboard_metrics():
    metadata = get_training_metadata()
    return {
        "algorithm": metadata.get("algorithm", "Unknown"),
        "r2_score": metadata.get("r2_score", 0.0),
        "dataset_rows": metadata.get("dataset_rows", 0),
        "dataset_columns": metadata.get("dataset_columns", 0),
        "features": metadata.get("features", []),
    }
