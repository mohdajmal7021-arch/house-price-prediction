const state = {
    token: localStorage.getItem("tk"),
    user: JSON.parse(localStorage.getItem("u") || "null"),
    history: JSON.parse(localStorage.getItem("h") || "[]"),
    theme: localStorage.getItem("th") || "light",
    nav: "home",
};

function saveState() {
    if (state.token) {
        localStorage.setItem("tk", state.token);
    } else {
        localStorage.removeItem("tk");
    }
    localStorage.setItem("u", JSON.stringify(state.user));
    localStorage.setItem("th", state.theme);
    localStorage.setItem("h", JSON.stringify(state.history));
}

async function api(endpoint, method, body) {
    const headers = { "Content-Type": "application/json" };
    if (state.token) {
        headers["Authorization"] = "Bearer " + state.token;
    }
    const res = await fetch("/api" + endpoint, {
        method: method || "GET",
        headers: headers,
        body: body ? JSON.stringify(body) : null,
    });
    const data = await res.json();
    if (!res.ok) {
        throw new Error(data.detail || "Request failed");
    }
    return data;
}

function showLanding() {
    document.getElementById("lp").style.display = "flex";
    document.getElementById("ap").style.display = "none";
    document.getElementById("app").style.display = "none";
}

function showAuth(form) {
    document.getElementById("lp").style.display = "none";
    document.getElementById("ap").style.display = "block";
    document.getElementById("app").style.display = "none";
    document.getElementById("lf").style.display = form === "login" ? "block" : "none";
    document.getElementById("rf").style.display = form === "register" ? "block" : "none";
}

function showApp() {
    document.getElementById("lp").style.display = "none";
    document.getElementById("ap").style.display = "none";
    document.getElementById("app").style.display = "block";
    var userEl = document.getElementById("header-user");
    if (userEl && state.user) {
        userEl.textContent = "\u{1F464} " + state.user.username;
    }
    loadPage(state.nav);
}

function setActivePill(page) {
    var pages = ["home", "predict", "analytics", "history", "about"];
    pages.forEach(function(p) {
        var el = document.getElementById("n_" + p);
        if (el) {
            if (p === page) {
                el.classList.add("active");
            } else {
                el.classList.remove("active");
            }
        }
    });
}

async function loadPage(page) {
    state.nav = page;
    setActivePill(page);
    if (page === "home") {
        await showHome();
    } else if (page === "predict") {
        showPredict();
    } else if (page === "analytics") {
        showAnalytics();
    } else if (page === "history") {
        showHistory();
    } else if (page === "about") {
        showAbout();
    }
}

async function handleRegister(e) {
    e.preventDefault();
    var form = new FormData(e.target);
    var data = Object.fromEntries(form);
    if (data.password !== data.confirm) {
        return toast("Passwords don't match!", "error");
    }
    try {
        var res = await api("/auth/register", "POST", {
            username: data.username,
            email: data.email,
            password: data.password,
        });
        toast(res.message || "Account created!", "success");
        showAuth("login");
    } catch (err) {
        toast(err.message, "error");
    }
}

async function handleLogin(e) {
    e.preventDefault();
    var form = new FormData(e.target);
    var data = Object.fromEntries(form);
    try {
        var res = await api("/auth/login", "POST", {
            username: data.username,
            password: data.password,
        });
        state.token = res.token;
        state.user = res.user;
        saveState();
        showApp();
    } catch (err) {
        toast(err.message, "error");
    }
}

function handleLogout() {
    state.token = null;
    state.user = null;
    state.history = [];
    state.nav = "home";
    saveState();
    showLanding();
}

async function showHome() {
    var metrics = { r2_score: 0, dataset_rows: 0 };
    try {
        metrics = await api("/dashboard/metrics");
    } catch (e) {}
    var html = "";
    html += '<div class="page-header"><h1>Welcome, <span style="color:var(--primary)">' + (state.user ? state.user.username : "User") + '</span> \u{1F44B}</h1><p>Real Estate Price Prediction System</p></div>';
    html += '<div class="metrics-grid">';
    html += '  <div class="metric-card"><div class="metric-value">' + (metrics.algorithm || "GB") + '</div><div class="metric-label">\u{1F916} Algorithm</div></div>';
    var r2 = metrics.r2_score || 0;
    html += '  <div class="metric-card"><div class="metric-value">' + (r2 * 100).toFixed(1) + '%</div><div class="metric-label">\u{1F4C8} R\u00B2 Score</div></div>';
    html += '  <div class="metric-card"><div class="metric-value">' + (metrics.dataset_rows || 0).toLocaleString() + '</div><div class="metric-label">\u{1F4CA} Records</div></div>';
    html += '  <div class="metric-card"><div class="metric-value">' + state.history.length + '</div><div class="metric-label">\u{1F4CB} Estimates</div></div>';
    html += '</div>';
    html += '<hr class="divider">';
    html += '<div class="quick-actions">';
    html += '  <div class="action-card" onclick="loadPage(\'predict\')"><div class="action-icon">\u{1F3E0}</div><h3>New Valuation</h3><p>Estimate property price</p></div>';
    html += '  <div class="action-card" onclick="loadPage(\'analytics\')"><div class="action-icon">\u{1F4CA}</div><h3>Analytics</h3><p>View trends & stats</p></div>';
    html += '  <div class="action-card" onclick="loadPage(\'history\')"><div class="action-icon">\u{1F4DC}</div><h3>History</h3><p>Past valuations</p></div>';
    html += '</div>';
    document.getElementById("pc").innerHTML = html;
}

function showPredict() {
    var html = "";
    html += '<div class="page-header"><h1>\u{1F3E0} Property Valuation</h1><p>Enter property details to estimate market value</p></div>';
    html += '<form id="pf" onsubmit="handlePredict(event)">';
    html += '  <div class="form-card">';
    html += '    <h3>\u{1F4D0} Size & Layout</h3>';
    html += '    <div class="form-grid">';
    html += '      <div class="form-group"><label>\u{1F6CF}\uFE0F Bedrooms</label><input type="number" name="bedrooms" id="f_bedrooms" value="3" min="0" max="20"></div>';
    html += '      <div class="form-group"><label>\u{1F6BF} Bathrooms</label><input type="number" name="bathrooms" id="f_bathrooms" value="2" min="0" max="20" step="0.5"></div>';
    html += '      <div class="form-group"><label>\u{1F3E0} Living Area (sqft)</label><input type="number" name="sqft_living" id="f_sqft_living" value="1800" min="100" max="50000"></div>';
    html += '      <div class="form-group"><label>\u{1F3D8}\uFE0F Lot Size (sqft)</label><input type="number" name="sqft_lot" id="f_sqft_lot" value="5000" min="500" max="500000"></div>';
    html += '      <div class="form-group"><label>\u{1F3E2} Floors</label><input type="number" name="floors" id="f_floors" value="1" min="0.5" max="10" step="0.5"></div>';
    html += '      <div class="form-group"><label>\u{1F3D8}\uFE0F Above Ground (sqft)</label><input type="number" name="sqft_above" id="f_sqft_above" value="1500" min="100" max="50000"></div>';
    html += '    </div>';
    html += '    <hr class="form-divider">';
    html += '    <h3>\u{2B50} Features & Condition</h3>';
    html += '    <div class="form-grid">';
    html += '      <div class="form-group"><label>\u{1F30A} Waterfront</label><select name="waterfront" id="f_waterfront"><option value="0">No</option><option value="1">Yes</option></select></div>';
    html += '      <div class="form-group"><label>\u{1F441}\uFE0F View (0-4)</label><input type="number" name="view" id="f_view" value="0" min="0" max="4"></div>';
    html += '      <div class="form-group"><label>\u{1F9F1} Condition (1-5)</label><input type="number" name="condition" id="f_condition" value="3" min="1" max="5"></div>';
    html += '      <div class="form-group"><label>\u{1F9F1} Basement (sqft)</label><input type="number" name="sqft_basement" id="f_sqft_basement" value="0" min="0" max="10000"></div>';
    html += '    </div>';
    html += '    <hr class="form-divider">';
    html += '    <h3>\u{1F4C5} Age & History</h3>';
    html += '    <div class="form-grid">';
    html += '      <div class="form-group"><label>\u{1F3D7}\uFE0F Year Built</label><input type="number" name="yr_built" id="f_yr_built" value="2000" min="1800" max="2026"></div>';
    html += '      <div class="form-group"><label>\u{1F528} Year Renovated (0=none)</label><input type="number" name="yr_renovated" id="f_yr_renovated" value="0" min="0" max="2026"></div>';
    html += '    </div>';
    html += '    <button type="submit" class="btn-primary">\u{1F3E0} Estimate Value</button>';
    html += '  </div>';
    html += '</form>';
    html += '<div id="rc"></div>';
    document.getElementById("pc").innerHTML = html;
}

async function handlePredict(e) {
    e.preventDefault();
    var btn = e.target.querySelector("button[type='submit']");
    btn.disabled = true;
    btn.textContent = "Calculating...";
    var data = {};
    var fields = ["bedrooms", "bathrooms", "sqft_living", "sqft_lot", "floors", "waterfront", "view", "condition", "sqft_above", "sqft_basement", "yr_built", "yr_renovated"];
    fields.forEach(function(name) {
        var el = document.getElementById("f_" + name);
        if (el) {
            data[name] = el.type === "number" ? parseFloat(el.value) : el.value;
        }
    });
    try {
        var result = await api("/predict", "POST", data);
        state.history.push({
            timestamp: new Date().toLocaleString(),
            bedrooms: data.bedrooms,
            bathrooms: data.bathrooms,
            sqft_living: data.sqft_living,
            sqft_lot: data.sqft_lot,
            predicted_price: result.predicted_price,
        });
        saveState();
        showResult(result, data);
    } catch (err) {
        toast(err.message, "error");
    }
    btn.disabled = false;
    btn.textContent = "\u{1F3E0} Estimate Value";
}

function showResult(result, data) {
    var price = result.predicted_price || 0;
    var ppsf = price / (data.sqft_living || 1);
    var html = "";
    html += '<div class="result-card">';
    html += '  <div class="result-label">Estimated Property Value</div>';
    html += '  <div class="result-price">$' + Number(price).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0}) + '</div>';
    html += '  <div class="result-grid">';
    html += '    <div class="result-item"><div class="result-item-label">\u{1F4B0} Price/sqft</div><div class="result-item-value">$' + ppsf.toFixed(0) + '</div></div>';
    html += '    <div class="result-item"><div class="result-item-label">\u{1F6CF}\uFE0F Bedrooms</div><div class="result-item-value">' + data.bedrooms + '</div></div>';
    html += '    <div class="result-item"><div class="result-item-label">\u{1F6BF} Bathrooms</div><div class="result-item-value">' + data.bathrooms + '</div></div>';
    html += '    <div class="result-item"><div class="result-item-label">\u{1F3E0} Living Area</div><div class="result-item-value">' + Number(data.sqft_living).toLocaleString() + ' sqft</div></div>';
    html += '  </div>';
    html += '</div>';
    document.getElementById("rc").innerHTML = html;
}

function showAnalytics() {
    if (!state.history.length) {
        document.getElementById("pc").innerHTML = '<div class="page-header"><h1>\u{1F4CA} Analytics</h1><p>Make predictions to see analytics</p></div><div class="empty-state">\u{1F50D} No data yet \u2014 try estimating a property first!</div>';
        return;
    }
    var vals = state.history.map(function(h) { return h.predicted_price || 0; });
    var sum = vals.reduce(function(a, b) { return a + b; }, 0);
    var avg = sum / vals.length;
    var mx = Math.max.apply(null, vals);
    var mn = Math.min.apply(null, vals);
    var recent = state.history.slice(-10);
    var html = "";
    html += '<div class="page-header"><h1>\u{1F4CA} Analytics Dashboard</h1><p>' + state.history.length + ' total valuations</p></div>';
    html += '<div class="metrics-grid">';
    html += '  <div class="metric-card"><div class="metric-value">$' + avg.toLocaleString() + '</div><div class="metric-label">\u{1F4B0} Average Price</div></div>';
    html += '  <div class="metric-card"><div class="metric-value">$' + mn.toLocaleString() + '</div><div class="metric-label">\u{2B07}\uFE0F Minimum</div></div>';
    html += '  <div class="metric-card"><div class="metric-value">$' + mx.toLocaleString() + '</div><div class="metric-label">\u{2B06}\uFE0F Maximum</div></div>';
    html += '  <div class="metric-card"><div class="metric-value">' + vals.length + '</div><div class="metric-label">\u{1F4CA} Total</div></div>';
    html += '</div>';
    html += '<div class="chart-card"><h3 style="margin-bottom:0.75rem;font-size:1rem;">\u{1F4C8} Recent Estimates</h3><canvas id="tc"></canvas></div>';
    html += '<button class="btn-secondary" onclick="loadPage(\'history\')" style="margin-top:1rem;width:auto;">\u{1F4DC} View All History</button>';
    document.getElementById("pc").innerHTML = html;
    setTimeout(function() { drawTrend(recent); }, 100);
}

function drawTrend(data) {
    var canvas = document.getElementById("tc");
    if (!canvas || data.length < 1) return;
    var ctx = canvas.getContext("2d");
    var rect = canvas.parentElement.getBoundingClientRect();
    canvas.width = rect.width - 32;
    canvas.height = 280;
    var w = canvas.width, h = canvas.height;
    var pt = 20, pb = 35, pl = 70, pr = 20;
    var cw = w - pl - pr, ch = h - pt - pb;
    if (cw <= 0 || ch <= 0) return;
    ctx.clearRect(0, 0, w, h);
    var vals = data.map(function(d) { return d.predicted_price || 0; });
    var mx = Math.max.apply(null, vals);
    var mn = Math.min.apply(null, vals);
    var range = mx - mn || 1;
    var sx = data.length > 1 ? cw / (data.length - 1) : cw;
    for (var i = 0; i <= 4; i++) {
        var y = pt + ch - (ch * i / 4);
        ctx.beginPath();
        ctx.strokeStyle = "var(--border)";
        ctx.lineWidth = 1;
        ctx.moveTo(pl, y);
        ctx.lineTo(w - pr, y);
        ctx.stroke();
        ctx.fillStyle = "var(--text-secondary)";
        ctx.font = "11px Inter";
        ctx.textAlign = "right";
        var val = mn + (range * i / 4);
        ctx.fillText("$" + Math.round(val).toLocaleString(), pl - 6, y + 4);
    }
    ctx.beginPath();
    ctx.strokeStyle = "var(--primary)";
    ctx.lineWidth = 3;
    ctx.lineJoin = "round";
    for (var i = 0; i < vals.length; i++) {
        var x = pl + (i * sx);
        var y = pt + ch - ((vals[i] - mn) / range) * ch;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.lineTo(pl + (vals.length - 1) * sx, pt + ch);
    ctx.lineTo(pl, pt + ch);
    ctx.closePath();
    var grad = ctx.createLinearGradient(0, pt, 0, pt + ch);
    grad.addColorStop(0, "rgba(99,102,241,0.25)");
    grad.addColorStop(1, "rgba(99,102,241,0.02)");
    ctx.fillStyle = grad;
    ctx.fill();
    for (var i = 0; i < vals.length; i++) {
        var x = pl + (i * sx);
        var y = pt + ch - ((vals[i] - mn) / range) * ch;
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fillStyle = "var(--primary)";
        ctx.fill();
    }
}

function showHistory() {
    if (!state.history.length) {
        document.getElementById("pc").innerHTML = '<div class="page-header"><h1>\u{1F4DC} History</h1><p>Your past valuations</p></div><div class="empty-state">\u{1F50D} No predictions yet!</div>';
        return;
    }
    var rows = state.history.slice().reverse().map(function(h) {
        return '<tr><td>' + (h.timestamp || "") + '</td><td>$' + Number(h.predicted_price || 0).toLocaleString() + '</td><td>' + (h.bedrooms || "") + '</td><td>' + (h.bathrooms || "") + '</td><td>' + Number(h.sqft_living || 0).toLocaleString() + '</td></tr>';
    }).join("");
    document.getElementById("pc").innerHTML = '<div class="page-header"><h1>\u{1F4DC} Valuation History</h1><p>' + state.history.length + ' records</p></div><div class="table-container"><table><thead><tr><th>Time</th><th>Price</th><th>Beds</th><th>Baths</th><th>Sqft</th></tr></thead><tbody>' + rows + '</tbody></table></div><button class="btn-secondary" onclick="exportCSV()" style="margin-top:0.5rem;width:auto;">\u{1F4E5} Export CSV</button>';
}

function exportCSV() {
    if (!state.history.length) return;
    var keys = Object.keys(state.history[0]);
    var csv = keys.join(",") + "\n";
    state.history.forEach(function(row) {
        csv += keys.map(function(k) {
            var v = row[k];
            if (typeof v === "string") return '"' + v.replace(/"/g, '""') + '"';
            return v;
        }).join(",") + "\n";
    });
    var blob = new Blob([csv], { type: "text/csv" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "home_prices.csv";
    a.click();
    URL.revokeObjectURL(a.href);
}

function showAbout() {
    var html = "";
    html += '<div class="page-header"><h1>\u{2139}\uFE0F About HomeValue AI</h1><p>How it works</p></div>';
    html += '<div class="about-section"><h2>\u{1F916} Intelligent Price Prediction</h2><p>Uses <strong>Gradient Boosting Regressor</strong> with log-transformed targets to estimate property values. The model analyzes size, layout, condition, location features, and age to deliver accurate market valuations.</p></div>';
    html += '<div class="about-section"><h2>\u{1F50D} Valuation Factors</h2><ul>';
    html += '<li>\u{1F4D0} <strong>Size & Layout</strong> \u2014 bedrooms, bathrooms, living area, lot size, floors</li>';
    html += '<li>\u{2B50} <strong>Features</strong> \u2014 waterfront, view rating, condition, basement</li>';
    html += '<li>\u{1F4C5} <strong>Age</strong> \u2014 year built, renovation history, property age</li>';
    html += '</ul></div>';
    html += '<div class="about-section"><h2>\u{1F4C8} Performance</h2><ul>';
    html += '<li>\u{1F916} Algorithm: Gradient Boosting Regressor</li>';
    html += '<li>\u{1F4CA} R\u00B2 Score: ~85% on test data</li>';
    html += '<li>\u{1F4CB} Training Data: 4,600+ property records</li>';
    html += '<li>\u{2699}\uFE0F Features: 13 engineered features</li>';
    html += '</ul></div>';
    html += '<hr class="divider">';
    html += '<p style="text-align:center;color:var(--text-secondary);font-size:0.9rem;">Built with \u2764\uFE0F using FastAPI &amp; Scikit-learn</p>';
    document.getElementById("pc").innerHTML = html;
}

function toggleTheme() {
    state.theme = state.theme === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", state.theme);
    saveState();
}

function toast(message, type) {
    type = type || "info";
    var el = document.getElementById("toast");
    el.textContent = message;
    el.className = "toast " + type;
    el.style.display = "block";
    setTimeout(function() { el.style.display = "none"; }, 3000);
}

document.addEventListener("DOMContentLoaded", function() {
    document.documentElement.setAttribute("data-theme", state.theme);
    if (state.token && state.user) {
        showApp();
    } else {
        showLanding();
    }
});
