from __future__ import annotations

from fastapi import Header, HTTPException

_tokens: dict[str, dict] = {}


def create_token(token: str, user: dict):
    _tokens[token] = user


def get_current_user(authorization: str = Header("")) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token")
    token = authorization[len("Bearer "):]
    user = _tokens.get(token)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid token")
    return user
