from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.dependencies import get_current_user
from utils.predictor import predict_price, get_dashboard_metrics

router = APIRouter(prefix="/api", tags=["predict"])


class PredictRequest(BaseModel):
    bedrooms: float = 3
    bathrooms: float = 2
    sqft_living: float = 1800
    sqft_lot: float = 5000
    floors: float = 1
    waterfront: str = ""
    view: float = 0
    condition: float = 3
    sqft_above: float = 1500
    sqft_basement: float = 0
    yr_built: float = 2000
    yr_renovated: float = 0


@router.post("/predict")
def predict(req: PredictRequest, user: dict = Depends(get_current_user)):
    result = predict_price(
        bedrooms=req.bedrooms,
        bathrooms=req.bathrooms,
        sqft_living=req.sqft_living,
        sqft_lot=req.sqft_lot,
        floors=req.floors,
        waterfront=req.waterfront,
        view=req.view,
        condition=req.condition,
        sqft_above=req.sqft_above,
        sqft_basement=req.sqft_basement,
        yr_built=req.yr_built,
        yr_renovated=req.yr_renovated,
    )
    result["user_id"] = user["id"]
    return result


@router.get("/dashboard/metrics")
def dashboard_metrics(user: dict = Depends(get_current_user)):
    return get_dashboard_metrics()
