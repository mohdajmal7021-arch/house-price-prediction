from __future__ import annotations

import hashlib
import secrets
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.dependencies import create_token
from auth_db import init_db, register_user, login_user

router = APIRouter(prefix="/api/auth", tags=["auth"])


class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


@router.post("/register")
def register(req: RegisterRequest):
    init_db()
    success, msg = register_user(req.username, req.email, req.password)
    if not success:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@router.post("/login")
def login(req: LoginRequest):
    init_db()
    success, result = login_user(req.username, req.password)
    if not success:
        raise HTTPException(status_code=401, detail=result)
    token = hashlib.sha256(f"{result['id']}:{secrets.token_hex(16)}".encode()).hexdigest()
    create_token(token, dict(result))
    return {"token": token, "user": {"id": result["id"], "username": result["username"], "email": result.get("email", "")}}
